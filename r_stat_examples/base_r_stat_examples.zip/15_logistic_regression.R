# Logistic regression in base R

set.seed(123)
n <- 300
x1 <- rnorm(n)
x2 <- rnorm(n)
eta <- -0.5 + 1.0 * x1 - 0.8 * x2
p <- 1 / (1 + exp(-eta))
y <- rbinom(n, size = 1, prob = p)

dat <- data.frame(y = y, x1 = x1, x2 = x2)

fit <- glm(y ~ x1 + x2, data = dat, family = binomial())

print(summary(fit))

cat("\nOdds ratios:\n")
print(exp(coef(fit)))

cat("\nPredicted probabilities for first six rows:\n")
print(head(predict(fit, type = "response")))
