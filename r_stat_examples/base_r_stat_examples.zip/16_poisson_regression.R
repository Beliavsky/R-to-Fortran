# Poisson regression in base R

set.seed(123)
n <- 300
x <- rnorm(n)
exposure <- runif(n, 0.5, 2.0)
lambda <- exposure * exp(0.3 + 0.7 * x)
y <- rpois(n, lambda = lambda)

dat <- data.frame(y = y, x = x, exposure = exposure)

fit <- glm(y ~ x + offset(log(exposure)), data = dat, family = poisson())

print(summary(fit))

cat("\nRate ratio for x:\n")
print(exp(coef(fit)["x"]))

cat("\nCheck for overdispersion:\n")
dispersion <- sum(resid(fit, type = "pearson")^2) / fit$df.residual
cat("Pearson dispersion =", dispersion, "\n")
